# دفتر الحساب — Debt Book

تطبيق ويب عربي بسيط لتسجيل البضاعة/الديون والدفعات مع سجل وفلترة حسب التاريخ. يعمل محليًا على الجهاز ويستخدم `localStorage` لحفظ البيانات في المتصفح.

## رفعه على GitHub
1. افتح المستودع `debt-book` على GitHub.
2. اضغط **Add file → Upload files**.
3. فك ضغط الملف ZIP على جهازك، ثم ارفع الملفات الموجودة بداخله مباشرة إلى جذر المستودع: `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`, و`README.md`.
4. اضغط **Commit changes**.

## نشره مجانًا عبر Cloudflare Pages
1. افتح Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages**.
2. اختر **Connect to Git** واربط مستودع GitHub `debt-book`.
3. اختر إعدادات نشر موقع ثابت: اترك Build command فارغًا، واجعل Build output directory `/` أو `.` حسب ما تعرضه الواجهة.
4. اضغط **Save and Deploy**. سيعطيك Cloudflare رابط HTTPS.
5. افتح الرابط في Chrome على Android ثم قائمة ⋮ واختر **Add to Home screen** أو **Install app** إذا ظهرت.

## تنبيه مهم للبيانات
البيانات محفوظة داخل متصفح/تخزين هذا الجهاز وليست متزامنة مع جهاز آخر. استخدم **الإعدادات → تصدير** بانتظام للاحتفاظ بنسخة احتياطية، خصوصًا قبل مسح بيانات المتصفح أو تغيير الجهاز.
